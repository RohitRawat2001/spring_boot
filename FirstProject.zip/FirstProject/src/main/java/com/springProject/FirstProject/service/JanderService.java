package com.springProject.FirstProject.service;

import com.springProject.FirstProject.DTO.JournalDTO;
import com.springProject.FirstProject.Entity.Jandar;
import com.springProject.FirstProject.Entity.User;
import com.springProject.FirstProject.repository.JandarRepository;
import com.springProject.FirstProject.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JanderService {
    @Autowired
    private JandarRepository jandarRepository;

  // Method to add Journal
    public void addJournal(JournalDTO journalDTO)
    {
        Jandar jandar= new Jandar();
        jandar.setUserId(journalDTO.getUserId());
        jandar.setName(journalDTO.getName());
        jandarRepository.save(jandar);
    }

    // Method to delete a user by ID
    public void deleteUser(int id) {
        if (!jandarRepository.existsById(id)) {
            throw new RuntimeException("User not found with id " + id);
        }else{
            jandarRepository.deleteById(id);

        }

    }




















//       @Transactional
//    public void addUsertoJandar(int jandarId , User user){
//        Jandar jandar = jandarRepository.findById(jandarId).orElseThrow(() -> new RuntimeException("User not found"));
//        //set the jander to user
//        user.setJandar(jandar);
//
//        // add user to janders users
//        jandar.getUser().add(user);
//
//        //save the jandar with new user
//        jandarRepository.save(jandar);
//
//
//
//    }

//    public Jandar saveJander(Jandar jandar){
//        return  jandarRepository.save(jandar);
//    }
//    public List<Jandar> saveJanders(List<Jandar> jandars){
//        return jandarRepository.saveAll(jandars);
//    }
//
//    public List<Jandar> getJandes(){
//        return jandarRepository.findAll();
//    }

}
