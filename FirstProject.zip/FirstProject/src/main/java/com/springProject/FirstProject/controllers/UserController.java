package com.springProject.FirstProject.controllers;

import com.springProject.FirstProject.DTO.JournalDTO;
import com.springProject.FirstProject.DTO.UserDTO;
import com.springProject.FirstProject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/adduser")
    public String createUser(@RequestBody UserDTO userDTO){
        userService.addUser(userDTO);
        return " User created Successfully😊 ";
    }

    //    @PostMapping
//    public void addUser(@RequestBody UserDTO userDTO) {
//        userService.addUser(userDTO);
//    }

//    @PutMapping
//    public void updateUser(@RequestBody UserDTO userDTO) {
//        userService.updateUser(userDTO);
//    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable int id) {
        userService.deleteUser(id);
    }


//    @GetMapping
//    public List<UserDTO> getAllUsers() {
//        return userService.getAllUsers();
//    }



}
