package com.springProject.FirstProject.repository;

import com.springProject.FirstProject.Entity.Jandar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JandarRepository extends JpaRepository<Jandar,Integer> {

}
