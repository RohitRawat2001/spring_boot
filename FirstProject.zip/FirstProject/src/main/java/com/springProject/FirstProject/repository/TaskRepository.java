package com.springProject.FirstProject.repository;

import com.springProject.FirstProject.Entity.Product;
import com.springProject.FirstProject.Entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task,Integer> {

}
