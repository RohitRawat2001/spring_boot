package com.springProject.FirstProject.service;

import com.springProject.FirstProject.Entity.Jandar;
import com.springProject.FirstProject.Entity.Product;
import com.springProject.FirstProject.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
   @Autowired
    private ProductRepository repository;

//   public Product saveProduct(Jandar product){
//       return repository.save(product);
//   }

//   public List<Jandar> saveProducts(List<Jandar> products) {
//        return repository.saveAll(products);
//    }
//
//    public List<Jandar> getProducts() {
//        return repository.findAll();
//    }

//    public Product getProductById(int id) {
//        return repository.findById(id).orElse(null);
//    }

//    public String deleteProduct(int id) {
//        repository.deleteById(id);
//        return "product removed !! " + id +  " using this Id";
//    }

//    public Jandar updateProduct(Jandar product) {
//        Jandar existingProduct = repository.findById(product.getId()).orElse(null);
//        existingProduct.setName(product.getName());
//        existingProduct.setQuantity(product.getQuantity());
//        existingProduct.setPrice(product.getPrice());
//        return repository.save(existingProduct);
//    }


}
