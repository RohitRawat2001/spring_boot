package com.springProject.FirstProject.controllers;

import com.springProject.FirstProject.DTO.JournalDTO;
import com.springProject.FirstProject.Entity.Jandar;
import com.springProject.FirstProject.Entity.User;
import com.springProject.FirstProject.service.JanderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jd")
public class JandarController {

    @Autowired
    private JanderService janderService;


@PostMapping("/addJournal")
public String addUser(@RequestBody JournalDTO journalDTO)
{
    janderService.addJournal(journalDTO);
    return "OK , Journal Created Successfully😂";
}


}
