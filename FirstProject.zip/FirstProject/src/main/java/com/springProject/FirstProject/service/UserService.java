package com.springProject.FirstProject.service;

import com.springProject.FirstProject.DTO.UserDTO;
import com.springProject.FirstProject.Entity.User;
import com.springProject.FirstProject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    //method to add user
  public void addUser(UserDTO userDTO){
      User user = new User();
      user.setName(userDTO.getName());
      user.setEmail(userDTO.getEmail());
      userRepository.save(user);
  }

//    // Method to update an existing user
//    public void updateUser(UserDTO userDTO) {
//        User existingUser = userRepository.findById(userDTO.getId())
//                .orElseThrow(() -> new RuntimeException("User not found with id " + userDTO.getId()));
//
//        existingUser.setName(userDTO.getName());
//        existingUser.setEmail(userDTO.getEmail());
//
//        userRepository.save(existingUser);
//    }

    // Method to delete a user by ID
    public String deleteUser(int id) {
        if (!userRepository.existsById(id)) {
            throw new RuntimeException("User not found with id " + id);
        }else {
            userRepository.deleteById(id);
            return "User deleted Successfully🤢";
        }
    }



}
