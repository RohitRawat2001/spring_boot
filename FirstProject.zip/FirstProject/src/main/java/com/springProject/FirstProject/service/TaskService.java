package com.springProject.FirstProject.service;

import com.springProject.FirstProject.DTO.TaskDTO;
import com.springProject.FirstProject.DTO.UserDTO;
import com.springProject.FirstProject.Entity.Task;
import com.springProject.FirstProject.Entity.User;
import com.springProject.FirstProject.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TaskService {
    @Autowired
    private TaskRepository taskRepository;

    //method to add task
    public void addTask(TaskDTO taskDTO){
        Task task = new Task();
        task.setTaskName(taskDTO.getTaskName());
        task.setRole(taskDTO.getRole());
        taskRepository.save(task);
    }

}
