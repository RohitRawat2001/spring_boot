package com.springProject.FirstProject.controllers;

import com.springProject.FirstProject.DTO.TaskDTO;
import com.springProject.FirstProject.DTO.UserDTO;
import com.springProject.FirstProject.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tk")
public class TaskController {
   @Autowired
    private TaskService taskService;

   @PostMapping("/addTask")
   public String createTask(@RequestBody TaskDTO taskDTO){
       taskService.addTask(taskDTO);
       return "task created successfully";
   }

}
