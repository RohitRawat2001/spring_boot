package com.springProject.FirstProject.DTO;

import com.springProject.FirstProject.Entity.User;

public class JournalDTO {


    public int getUserId() {
        return userId;
    }

    public void setUser(int userId) {
        this.userId = userId;
    }

    private int userId;
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
