package com.BackendProject.Blog.services.Impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.BackendProject.Blog.entities.Category;
import com.BackendProject.Blog.entities.Post;
import com.BackendProject.Blog.entities.User;
import com.BackendProject.Blog.exceptions.ResourceNotFoundException;
import com.BackendProject.Blog.payloads.CategoryDto;
import com.BackendProject.Blog.payloads.PostDto;
import com.BackendProject.Blog.payloads.PostResponse;
import com.BackendProject.Blog.respositories.CategoryRepo;
import com.BackendProject.Blog.respositories.PostRepo;
import com.BackendProject.Blog.respositories.UserRepo;
import com.BackendProject.Blog.services.PostService;

@Service
public class PostServiceImpl implements PostService {

        @Autowired
        private PostRepo postRepo;

        @Autowired
        private ModelMapper modelMapper;

        @Autowired
        private UserRepo userRepo;

        @Autowired
        private CategoryRepo categoryRepo;

        @Override
        public PostDto createPost(PostDto postDto, Integer userId, Integer categoryId) {
                User user = userRepo.findById(userId)
                                .orElseThrow(() -> new ResourceNotFoundException("User", "User Id", userId));
                Post post = modelMapper.map(postDto, Post.class);

                Category category = categoryRepo.findById(categoryId)
                                .orElseThrow(() -> new ResourceNotFoundException("Category", "Category Id",
                                                categoryId));
                // ya humna Dto m pass nahi kra hai esliya set krdiya hai or User and Category
                // ko hum URL ka through liying
                post.setImageName("default.png");
                post.setAddedDate(new Date());
                post.setUser(user);
                post.setCategory(category);
                Post savedPost = postRepo.save(post);
                return modelMapper.map(savedPost, PostDto.class);
        }

        @Override
        public void deletePost(Integer postId) {
                Post post = postRepo.findById(postId)
                                .orElseThrow(() -> new ResourceNotFoundException("Post", "Post Id", postId));
                postRepo.delete(post);
        }

        @Override
        public PostResponse getAllPost(Integer pageNumber, Integer pageSize, String sortBy, String sortDir) {
                Sort sort = null;
                if (sortDir.equalsIgnoreCase("asc")) {
                        sort = Sort.by(sortBy).ascending();
                } else {
                        sort = Sort.by(sortBy).descending();

                }
                // pageable object for paging and sorting also here
                Pageable p = PageRequest.of(pageNumber, pageSize, sort);

                Page<Post> pagePosts = postRepo.findAll(p);
                List<Post> allPosts = pagePosts.getContent();

                List<PostDto> postDtos = allPosts.stream().map(post -> modelMapper.map(post, PostDto.class))
                                .collect(Collectors.toList());

                PostResponse postResponse = new PostResponse();

                postResponse.setContent(postDtos);
                postResponse.setPageNumber(pagePosts.getNumber());
                postResponse.setPageSize(pagePosts.getSize());
                postResponse.setTotalElements(pagePosts.getTotalElements());
                postResponse.setTotalPages(pagePosts.getTotalPages());
                postResponse.setLastPage(pagePosts.isLast());

                return postResponse;
        }

        @Override
        public PostDto getPostById(Integer postId) {
                Post post = postRepo.findById(postId)
                                .orElseThrow(() -> new ResourceNotFoundException("Post", "Post Id", postId));
                return modelMapper.map(post, PostDto.class);
        }

        @Override
        public List<PostDto> getPostsByCategory(Integer categoryId) {
                // find cat Id
                Category cat = categoryRepo.findById(categoryId)
                                .orElseThrow(() -> new ResourceNotFoundException("Category", "Category Id",
                                                categoryId));
                // find all post of cat Id
                List<Post> posts = postRepo.findByCategory(cat);
                // Par hama PostDto return krna hai esliya convert Post to PostDto
                List<PostDto> postDtos = posts.stream().map((post) -> modelMapper.map(post, PostDto.class))
                                .collect(Collectors.toList());
                return postDtos;
        }

        @Override
        public List<PostDto> getPostsByUser(Integer userId) {
                // find user Id
                User user = userRepo.findById(userId)
                                .orElseThrow(() -> new ResourceNotFoundException("User", "User Id", userId));
                // find all post of user Id
                List<Post> posts = postRepo.findByUser(user);
                // Par hama PostDto return krna hai esliya convert Post to PostDto
                List<PostDto> postDtos = posts.stream().map((post) -> modelMapper.map(post, PostDto.class))
                                .collect(Collectors.toList());
                return postDtos;
        }

        @Override
        public List<PostDto> searchPosts(String keyword) {
                List<Post> posts = postRepo.findByTitleContaining(keyword);
                List<PostDto> postDtos = posts.stream().map(post -> modelMapper.map(post, PostDto.class))
                                .collect(Collectors.toList());

                return postDtos;
        }

        @Override
        public PostDto updatePost(PostDto postDto, Integer postId) {
                Post post = postRepo.findById(postId)
                                .orElseThrow(() -> new ResourceNotFoundException("Post", "Post Id", postId));

                post.setTitle(postDto.getTitle());
                post.setContent(postDto.getContent());
                post.setImageName(postDto.getImageName());

                Post updatedPost = postRepo.save(post);
                return modelMapper.map(updatedPost, PostDto.class);

        }

}
