package com.BackendProject.Blog.services;

import java.util.List;

import com.BackendProject.Blog.entities.Post;
import com.BackendProject.Blog.payloads.PostDto;
import com.BackendProject.Blog.payloads.PostResponse;

public interface PostService {

    // create
    PostDto createPost(PostDto postDto, Integer userId, Integer categoryId);

    // update
    PostDto updatePost(PostDto postDto, Integer postId);

    // delete
    void deletePost(Integer postId);

    // get All posts // we return PostResponse for paging . In PostResponse all
    // information is stored
    PostResponse getAllPost(Integer pageNumber, Integer pageSize, String sortBy, String sortDir);

    // get Single post
    PostDto getPostById(Integer postId);

    // get all posts by category
    List<PostDto> getPostsByCategory(Integer categoryId);

    // get all posts by user
    List<PostDto> getPostsByUser(Integer userId);

    // search Posts
    List<PostDto> searchPosts(String keyword);
}
