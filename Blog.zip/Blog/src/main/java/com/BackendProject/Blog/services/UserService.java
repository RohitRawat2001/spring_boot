package com.BackendProject.Blog.services;

import java.util.List;

import com.BackendProject.Blog.payloads.UserDto;

// service is for business logics
public interface UserService {
    UserDto createUser(UserDto user);

    UserDto updateUser(UserDto user, Integer userId);

    UserDto getUserById(Integer userId);

    List<UserDto> getAllUsers();

    void deleteUser(Integer userId);
}
