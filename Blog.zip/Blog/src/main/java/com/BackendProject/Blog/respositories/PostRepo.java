package com.BackendProject.Blog.respositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BackendProject.Blog.entities.Category;
import com.BackendProject.Blog.entities.Post;
import com.BackendProject.Blog.entities.User;

public interface PostRepo extends JpaRepository<Post, Integer> {

    // custom methods
    List<Post> findByUser(User user);

    List<Post> findByCategory(Category category);

    // searching based on title if you want search based on content use like this =
    // findByContentContaining
    List<Post> findByTitleContaining(String title);

}
