package com.BackendProject.Blog.services;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {

    // upload Images
    String uploadImage(String path, MultipartFile multipartFile) throws IOException;

    // serve Images
    InputStream getResource(String path, String fileName) throws FileNotFoundException;

}
