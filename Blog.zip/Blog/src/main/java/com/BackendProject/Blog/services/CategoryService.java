package com.BackendProject.Blog.services;

import java.util.List;

import com.BackendProject.Blog.payloads.CategoryDto;

public interface CategoryService {

    // create
    CategoryDto createCategory(CategoryDto categoryDto);

    // update
    CategoryDto updateCategory(CategoryDto categoryDto, Integer categoryId);

    // delete
    void deleteCategory(Integer categoryId);

    // get All Category
    List<CategoryDto> getAllCategory();

    // get single category
    CategoryDto getCategoryById(Integer categoryId);

}
