package com.BackendProject.Blog.services.Impl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BackendProject.Blog.entities.Category;
import com.BackendProject.Blog.entities.Comment;
import com.BackendProject.Blog.entities.Post;
import com.BackendProject.Blog.exceptions.ResourceNotFoundException;
import com.BackendProject.Blog.payloads.CommentDto;
import com.BackendProject.Blog.respositories.CommentRepo;
import com.BackendProject.Blog.respositories.PostRepo;
import com.BackendProject.Blog.services.CommentService;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepo commentRepo;

    @Autowired
    private PostRepo postRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public CommentDto createComment(CommentDto commentDto, Integer postId) {
        Post post = postRepo.findById(postId)
                .orElseThrow(() -> new ResourceNotFoundException("Post", "Post Id", postId));

        Comment comment = modelMapper.map(commentDto, Comment.class);
        comment.setPost(post);
        Comment savedComment = commentRepo.save(comment);

        return modelMapper.map(savedComment, CommentDto.class);
    }

    @Override
    public void deleteComment(Integer commentId) {
        Comment comment = commentRepo.findById(commentId)
                .orElseThrow(() -> new ResourceNotFoundException("Comment", "Comment Id", commentId));

        commentRepo.delete(comment);
    }

}
