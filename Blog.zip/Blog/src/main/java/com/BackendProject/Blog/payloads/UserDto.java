package com.BackendProject.Blog.payloads;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class UserDto {

    private int id;

    @NotBlank
    @Size(min = 2, message = "Username must be min of 2 characters !!")
    private String name;

    @Email(message = "Email is invalid !!")
    private String email;

    @NotBlank
    @Size(min = 5, message = "password must be of 5 characters !!")
    private String password;

    @NotBlank
    private String about;

}
