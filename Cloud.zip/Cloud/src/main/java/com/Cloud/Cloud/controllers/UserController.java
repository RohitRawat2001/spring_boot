package com.Cloud.Cloud.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/user")
public class UserController {

    //user dashboard Page
    @RequestMapping(value = "/dashboard")
    public String userDashboard() {
        return "user/dashboard";
    }
    
    //user Profile Page
    @RequestMapping(value = "/profile")
    public String userProfile() {
        return "user/profile";
    }
    
    //user and contacts Page

    //user views contacts

    //user edit page

    //user delete Page


}
