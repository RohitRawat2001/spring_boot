package com.Cloud.Cloud.config;

public class SecurityConfig {

}
