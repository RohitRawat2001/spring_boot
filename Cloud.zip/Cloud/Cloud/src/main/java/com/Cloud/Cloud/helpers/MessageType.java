package com.Cloud.Cloud.helpers;

public enum MessageType {

    blue,red,green,yellow
}
