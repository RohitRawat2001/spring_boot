package com.Cloud.Cloud.entities;

public enum Providers {
    SELF,GOOGLE,GITHUB

}
